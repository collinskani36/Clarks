import React from "react";
import { Bell, Package, RefreshCw, Zap, Tag } from "lucide-react";

interface Notification {
  id: string;
  type: "new-drop" | "restock" | "price-drop" | "sold";
  title: string;
  body: string;
  time: string;
  unread: boolean;
  icon: React.ReactNode;
  iconBg: string;
}

const notifications: Notification[] = [
  {
    id: "1",
    type: "new-drop",
    title: "New Drop 🔥",
    body: "Jordan 1 Retro High Chicago just landed. Only 1 available – don't sleep.",
    time: "2m ago",
    unread: true,
    icon: <Zap size={16} fill="hsl(var(--primary))" color="hsl(var(--primary))" />,
    iconBg: "hsl(var(--primary-dim))",
  },
  {
    id: "2",
    type: "restock",
    title: "Restock Alert",
    body: "Air Force 1 White (UK 9) is back in stock. Limited quantity.",
    time: "1h ago",
    unread: true,
    icon: <RefreshCw size={16} color="hsl(var(--success))" />,
    iconBg: "hsl(142 72% 15%)",
  },
  {
    id: "3",
    type: "price-drop",
    title: "Price Drop 💸",
    body: "Lakers #24 Jersey dropped from $70 to $55. Grab it before it's gone.",
    time: "3h ago",
    unread: true,
    icon: <Tag size={16} color="hsl(var(--primary))" />,
    iconBg: "hsl(var(--primary-dim))",
  },
  {
    id: "4",
    type: "new-drop",
    title: "New Drop 🔥",
    body: "Yeezy Boost 350 V2 Zebra just added. 8/10 condition, verified authentic.",
    time: "6h ago",
    unread: false,
    icon: <Package size={16} color="hsl(var(--foreground-muted))" />,
    iconBg: "hsl(var(--surface-3))",
  },
  {
    id: "5",
    type: "sold",
    title: "Gone Already",
    body: "Nike Dunk Low Panda (UK 9) you saved was just sold. Check similar items.",
    time: "1d ago",
    unread: false,
    icon: <Bell size={16} color="hsl(var(--foreground-muted))" />,
    iconBg: "hsl(var(--surface-3))",
  },
  {
    id: "6",
    type: "restock",
    title: "Watch List",
    body: "Jordan 4 Black Cat you liked has a new similar item in stock.",
    time: "2d ago",
    unread: false,
    icon: <RefreshCw size={16} color="hsl(var(--foreground-muted))" />,
    iconBg: "hsl(var(--surface-3))",
  },
];

const NotificationsPage: React.FC = () => {
  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-30 glass-dark border-b border-border px-4 py-3 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl text-gradient tracking-wider">ALERTS</h1>
          <p className="text-xs text-foreground-muted">Stay on top of drops & restocks</p>
        </div>
        <div className="px-2 py-0.5 rounded-full bg-primary/20 border border-primary/30">
          <span className="text-xs font-bold text-primary">
            {notifications.filter((n) => n.unread).length} new
          </span>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto pb-24">
        <div className="divide-y divide-border">
          {notifications.map((notif, i) => (
            <div
              key={notif.id}
              className={`px-4 py-4 flex gap-3 transition-colors animate-fade-up ${
                notif.unread ? "bg-surface-1" : "bg-background"
              }`}
              style={{ animationDelay: `${i * 50}ms` }}
            >
              {/* Icon */}
              <div
                className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center"
                style={{ backgroundColor: notif.iconBg }}
              >
                {notif.icon}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <p
                    className={`text-sm font-semibold ${
                      notif.unread ? "text-foreground" : "text-foreground-muted"
                    }`}
                  >
                    {notif.title}
                  </p>
                  <span className="text-[10px] text-foreground-subtle flex-shrink-0 mt-0.5">{notif.time}</span>
                </div>
                <p className={`text-xs leading-relaxed mt-0.5 ${notif.unread ? "text-foreground-muted" : "text-foreground-subtle"}`}>
                  {notif.body}
                </p>
              </div>

              {/* Unread dot */}
              {notif.unread && (
                <div className="flex-shrink-0 w-2 h-2 rounded-full bg-primary mt-1.5 shadow-glow-sm" />
              )}
            </div>
          ))}
        </div>

        <div className="text-center py-8 text-foreground-subtle text-xs px-4">
          <p>You've seen all your notifications</p>
          <p className="mt-1">We'll ping you when new drops land 🔔</p>
        </div>
      </div>
    </div>
  );
};

export default NotificationsPage;
