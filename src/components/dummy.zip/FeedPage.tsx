import React, { useState } from "react";
import { products } from "@/data/products";
import ProductCard from "./ProductCard";
import ProductDetailModal from "./ProductDetailModal";
import { Product } from "@/data/products";
import { Search, Crown } from "lucide-react";
import logoImg from "@/assets/logo.png";

interface FeedPageProps {
  onLike: (id: string) => void;
  onWishlistToggle: (id: string) => void;
  wishlistIds: Set<string>;
}

const FeedPage: React.FC<FeedPageProps> = ({ onLike, onWishlistToggle, wishlistIds }) => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const feedProducts = products.map((p) => ({ ...p, isLiked: wishlistIds.has(p.id) }));

  return (
    <div className="flex flex-col h-full">
      {/* Top bar */}
      <header className="sticky top-0 z-30 glass-dark border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <img src={logoImg} alt="Sole Vault" className="w-8 h-8 object-contain" loading="lazy" width={32} height={32} />
          <span className="font-display text-xl text-gradient tracking-wider">SOLE VAULT</span>
        </div>
        <button className="p-2 rounded-full bg-surface-2 border border-border text-foreground-muted hover:text-foreground transition-colors active:scale-90">
          <Search size={18} />
        </button>
      </header>

      {/* Stories row (category quick links) */}
      <div className="flex gap-3 px-4 py-3 overflow-x-auto bg-surface-1 border-b border-border">
        {["All", "Sneakers", "Jordans", "AF1", "Jerseys", "New"].map((cat, i) => (
          <button
            key={cat}
            className={`flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-semibold border transition-all active:scale-95 ${
              i === 0
                ? "bg-gradient-primary text-primary-foreground border-primary shadow-glow-sm"
                : "bg-surface-2 text-foreground-muted border-border hover:border-primary/40"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Feed */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-md mx-auto space-y-4 p-3 pb-24">
          {feedProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onLike={onLike}
              onOpenDetail={setSelectedProduct}
              onWishlistToggle={onWishlistToggle}
            />
          ))}

          {/* End of feed */}
          <div className="text-center py-8 text-foreground-subtle text-sm">
            <Crown size={20} className="mx-auto mb-2 text-primary opacity-50" />
            <p>You're all caught up!</p>
            <p className="text-xs mt-1">New drops coming soon 🔥</p>
          </div>
        </div>
      </div>

      {/* Product detail modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={{ ...selectedProduct, isLiked: wishlistIds.has(selectedProduct.id) }}
          onClose={() => setSelectedProduct(null)}
          onWishlistToggle={onWishlistToggle}
        />
      )}
    </div>
  );
};

export default FeedPage;
